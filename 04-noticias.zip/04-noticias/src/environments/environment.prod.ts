export const environment = {
  production: true,
  apiKey: 'dc62b49904694e81adf392d7e45a2365',
  apiUlr: 'https://newsapi.org/v2'
};
